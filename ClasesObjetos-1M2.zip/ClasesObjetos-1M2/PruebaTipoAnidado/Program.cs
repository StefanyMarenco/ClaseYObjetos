﻿Modelo.Contenedora contenedora = new();
contenedora.AnidadaEscribirMensaje();

Modelo.Estaciones estaciones = new();
Console.WriteLine(estaciones.Invierno.MesInicio);
