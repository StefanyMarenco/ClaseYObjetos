﻿using PruebaClaseParcial;

Persona objP = new Persona();
objP.Nombre = "Susana";
objP.Apellido = "López";

Console.WriteLine(objP.GetNombreCompleto());
